DROP TABLE IF EXISTS delivery_diff_summary;

CREATE TABLE delivery_diff_summary AS
SELECT
    g.geolocation_state AS state,
    ROUND(
        AVG(julianday(o.order_estimated_delivery_date) - julianday(o.order_delivered_customer_date))
    ) AS delivery_diff_days
FROM olist_orders o
JOIN olist_customers c ON o.customer_id = c.customer_id
JOIN (
    SELECT
        geolocation_zip_code_prefix,
        MIN(geolocation_state) AS geolocation_state
    FROM olist_geolocation
    GROUP BY geolocation_zip_code_prefix
) g ON c.customer_zip_code_prefix = g.geolocation_zip_code_prefix
WHERE
    o.order_status = 'delivered'
    AND o.order_delivered_customer_date IS NOT NULL
    AND o.order_estimated_delivery_date IS NOT NULL
GROUP BY g.geolocation_state;


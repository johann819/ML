SELECT
    COUNT(*) AS order_count,
    CAST(STRFTIME('%s', DATE(o.order_purchase_timestamp)) AS INTEGER) * 1000 AS date,
    CASE
        WHEN ph.date IS NOT NULL THEN 'true'
        ELSE 'false'
    END AS holiday
FROM
    olist_orders o
LEFT JOIN
    public_holidays ph ON DATE(o.order_purchase_timestamp) = ph.date
WHERE
    STRFTIME('%Y', o.order_purchase_timestamp) = '2017'
GROUP BY
    date, holiday
ORDER BY
    date;